1. https://www.python.org/downloads/에 접속해서 파이썬을 설치한다
2. https://studyhard24.tistory.com/234를 참고하여 pip install beautifulsoup4를 입력하여 설치 후에 pip install openpyxl 를 한번 더 입력해준다.
3. 파이썬 파일을 한번 실행시키면 해당 파이썬 파일 위치에 url.txt파일이 생성될 것이다.
4. 재고확인할 iherb 제품 링크를 원하는 만큼 메모장에 입력 엔터를 반복한다.
5. 파이썬 파일을 한번 더 실행시키면 프로그램이 작동하여 1분마다 크롤링을 반복 할 것이다.
6. 파이썬 파일 위치에 새로 생긴 newstock.xlsx파일을 열어보면서 재고를 파악할 수 있다.
7. 재고 새로고침 시에는 엑셀 프로그램을 종료하고 다시 실행시켜주어야 한다.